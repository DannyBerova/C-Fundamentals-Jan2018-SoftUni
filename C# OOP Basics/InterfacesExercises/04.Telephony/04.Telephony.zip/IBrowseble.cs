﻿public interface IBrowseble
{
    string Browsing(string url);
}

