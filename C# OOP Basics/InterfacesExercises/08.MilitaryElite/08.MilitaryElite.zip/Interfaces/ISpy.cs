﻿public interface ISpy : ISoldier
{
    int CodeNumber { get; }
}