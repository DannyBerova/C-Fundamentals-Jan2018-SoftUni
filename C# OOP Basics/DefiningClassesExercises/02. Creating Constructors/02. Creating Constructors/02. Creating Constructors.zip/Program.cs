﻿//using System;
//using System.Reflection;

public class Program
{
    static void Main(string[] args)
    {
       
    }
}
