﻿public abstract class CorDraw
{
    public abstract void Draw();
}