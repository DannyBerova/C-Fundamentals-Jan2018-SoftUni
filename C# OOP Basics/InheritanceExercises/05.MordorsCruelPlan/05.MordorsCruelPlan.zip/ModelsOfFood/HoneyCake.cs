﻿namespace _05.MordorsCruelPlan
{
    public class HoneyCake : Food
    {
        public HoneyCake() : base(5)
        {
        }
    }
}
