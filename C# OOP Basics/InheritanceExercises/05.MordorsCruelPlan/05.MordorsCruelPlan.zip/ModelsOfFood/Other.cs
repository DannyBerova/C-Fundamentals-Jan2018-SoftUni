﻿namespace _05.MordorsCruelPlan
{
    public class Other : Food
    {
        public Other() : base(-1)
        {
        }
    }
}
