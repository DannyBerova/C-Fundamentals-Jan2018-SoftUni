﻿namespace _05.MordorsCruelPlan
{
    public class Melon : Food
    {
        public Melon() : base(1)
        {
        }
    }
}
