﻿namespace _05.MordorsCruelPlan
{
    public class Angry : Mood
    {
    }
}
