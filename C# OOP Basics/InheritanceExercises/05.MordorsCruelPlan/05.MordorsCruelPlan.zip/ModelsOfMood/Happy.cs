﻿namespace _05.MordorsCruelPlan
{
    public class Happy : Mood
    {
    }
}
