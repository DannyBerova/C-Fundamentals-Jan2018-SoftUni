﻿namespace _05.MordorsCruelPlan
{
    public abstract class Mood
    {
        public override string ToString()
        {
            return $"{GetType().Name}";
        }
    }
}
