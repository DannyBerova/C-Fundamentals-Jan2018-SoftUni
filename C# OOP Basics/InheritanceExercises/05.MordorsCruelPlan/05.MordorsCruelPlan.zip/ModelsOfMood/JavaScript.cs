﻿namespace _05.MordorsCruelPlan
{
    public class JavaScript : Mood
    {
    }
}
