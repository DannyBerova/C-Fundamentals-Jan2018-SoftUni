﻿public class NightVision : Ammunition
{
    public const double WeightPoint = 0.8;

    public NightVision(string name)
        : base(name, 0.8)
    {
    }
}