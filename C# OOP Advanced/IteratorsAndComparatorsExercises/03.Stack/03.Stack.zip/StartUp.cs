﻿public class StartUp
{
    static void Main()
    {
        var commandInterpreter = new ComandInterpreter();
        commandInterpreter.Run();
    }
}

