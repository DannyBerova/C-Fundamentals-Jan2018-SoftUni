﻿public class StartUp
{
    public static void Main()
    {
        var commandInterpreter = new ComandInterpreter();
        commandInterpreter.Run();
    }
}

