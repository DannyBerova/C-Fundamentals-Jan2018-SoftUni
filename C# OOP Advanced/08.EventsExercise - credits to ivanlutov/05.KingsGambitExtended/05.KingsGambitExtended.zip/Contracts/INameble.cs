﻿namespace _05.KingsGambitExtended.Contracts
{
    public interface INameble
    {
        string Name { get; }
    }
}