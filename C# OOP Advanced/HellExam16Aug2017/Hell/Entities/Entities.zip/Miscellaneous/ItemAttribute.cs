﻿using System;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Method | AttributeTargets.Field)]
public class ItemAttribute : Attribute
{
}

