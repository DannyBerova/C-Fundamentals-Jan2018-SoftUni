﻿public interface IItem
{
    int AgilityBonus { get; }
    int DamageBonus { get; }
    int HitPointsBonus { get; }
    int IntelligenceBonus { get; }
    string Name { get; }
    int StrengthBonus { get; }
}
