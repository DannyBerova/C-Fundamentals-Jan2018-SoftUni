﻿namespace BashSoft.Contracts
{
    public interface IDirectoryManager : IDirectoryTraverser, IDirectoryCreator, IDirectoryChanger
    {
    }
}
