﻿namespace BashSoft
{
    public  class DirectoryInfo
    { 
    }
}
