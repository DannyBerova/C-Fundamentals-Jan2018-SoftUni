﻿using System;

namespace _09.DateTimeNowAddDays
{
    public interface IDateTimeNow
    {
        DateTime Now { get; set; }
    }
}
