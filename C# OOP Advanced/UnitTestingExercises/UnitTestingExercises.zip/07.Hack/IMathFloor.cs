﻿namespace _07.Hack
{
    public interface IMathFloor
    {
        double MathFloor(double value);
    }
}
