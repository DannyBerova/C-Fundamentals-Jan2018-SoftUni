﻿namespace _07.Hack
{
    public interface IMathAbs
    {
        double MathAbs(double value);
    }
}
