﻿namespace _06.Tweeter
{
    public interface ITweet
    {
        string Message { get; set; }
    }
}