﻿namespace _01.Database
{
   public class StartUp
    {
       public static void Main()
        {
            //All of the unit tests for the problems are in the UnitTests Project.
            //Any class in UnitTests Project coresponds to diffrent problem Project with the same name (without "Tests" at the end).
            //Where needed interfaces are extracted in the coresponding problem project.
            //The lack of consistency in UnitTests Project is just for the sake of testing diffrent strategies and approaches.
        }
    }
}
