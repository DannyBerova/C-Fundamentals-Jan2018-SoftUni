﻿namespace _Logger.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}