﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _Logger.Models.Enums
{
    public enum ReportLevel
    {
        INFO,
        WARNING,
        ERROR,
        CRITICAL,
        FATAL
    }
}
