﻿public class StandartProvider : Provider
{
    public StandartProvider(int id, double energyOutput)
        : base(id, energyOutput)
    {
    }
}