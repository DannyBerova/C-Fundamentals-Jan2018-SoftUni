﻿using System;

public class RefreshEntitiesAttribute : Attribute
{
}