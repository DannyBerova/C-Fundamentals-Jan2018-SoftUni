﻿namespace _08.CreateCustomClassAttribute
{

    [WeaponAttribute("Pesho", 3, "Used for C# OOP Advanced Course - Enumerations and Attributes.", "Pesho", "Svetlio")]
    public abstract class Weapon
    {
        public Weapon()
        {

        }

    }
}


