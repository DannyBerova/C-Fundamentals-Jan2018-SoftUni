﻿namespace _07.InfernoInfinity.Models.Enums
{
    public enum WeaponType
    {
        Axe,
        Sword,
        Knife
    }
}
