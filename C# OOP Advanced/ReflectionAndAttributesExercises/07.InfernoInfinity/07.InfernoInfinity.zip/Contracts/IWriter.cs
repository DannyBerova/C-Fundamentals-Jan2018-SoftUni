﻿namespace _07.InfernoInfinity.Contracts
{
    public interface IWriter
    {
        void WriteLine(string result);
    }
}
