﻿namespace _07.InfernoInfinity.Contracts
{
    interface IReader
    {
        string ReadLine();
    }
}
