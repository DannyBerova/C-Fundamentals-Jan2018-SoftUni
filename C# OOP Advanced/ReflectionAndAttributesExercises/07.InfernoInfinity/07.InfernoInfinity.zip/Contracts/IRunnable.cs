﻿namespace _07.InfernoInfinity.Contracts
{
   public interface IRunnable
    {
        void Run();
    }
}
