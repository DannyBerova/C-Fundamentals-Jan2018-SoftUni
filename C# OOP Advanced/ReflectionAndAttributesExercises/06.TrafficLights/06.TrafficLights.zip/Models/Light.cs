﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.TrafficLights.Models
{
    public enum Light
{
    Red = 0,
    Green = 1,
    Yellow = 2
}
}
