﻿using System;

namespace _03BarracksFactory.Core.Commands
{
    public class InjectAttribute : Attribute
    {
    }
}
